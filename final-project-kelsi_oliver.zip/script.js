var topSelected = false;
var bottomSelected = false;
var top = "";
var bottom = "";

$("#choose-1").click(findTop)

function findTop(){
	top = $(".box1")
	console.log(top);
}